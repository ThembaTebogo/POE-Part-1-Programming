package chatapppoe;

import org.junit.Test;
import static org.junit.Assert.*;

public class MessageSystemPart3Test {

    @Test
    public void testSentMessagesArrayPopulation() {
        System.out.println("Testing Sent Messages Array Population");
        
        // Initialize test data first
        MessageSystem.populateTestData();
        String[] sentMessages = MessageSystem.getSentMessagesArray();
        
        // Check that array contains expected test data
        boolean foundMessage1 = false;
        boolean foundMessage4 = false;
        
        if (sentMessages != null) {
            for (String message : sentMessages) {
                if (message != null) {
                    if (message.contains("Did you get the cake?")) {
                        foundMessage1 = true;
                    }
                    if (message.contains("It is dinner time !")) {
                        foundMessage4 = true;
                    }
                }
            }
        }
        
        assertTrue("Should contain 'Did you get the cake?'", foundMessage1);
        assertTrue("Should contain 'It is dinner time !'", foundMessage4);
    }

    @Test
    public void testLongestMessage() {
        System.out.println("Testing Longest Message");
        
        MessageSystem.populateTestData();
        String longest = MessageSystem.getLongestMessage();
        System.out.println("Longest message: '" + longest + "'");
        
        assertNotNull("Longest message should not be null", longest);
        assertFalse("Longest message should not be empty", longest.isEmpty());
        // Test that it contains one of the expected messages
        assertTrue("Longest message should contain expected content", 
                   longest.contains("Did you get the cake?") || 
                   longest.contains("It is dinner time !") ||
                   longest.contains("Sender: System"));
    }

    @Test
    public void testSearchMessageById() {
        System.out.println("Testing Search Message by ID");
        
        MessageSystem.populateTestData();
        String result = MessageSystem.searchMessageById("0838884567");
        
        assertNotNull("Search result should not be null", result);
        assertFalse("Search result should not be empty", result.isEmpty());
        // Since your method returns the full message string, check for content
        assertTrue("Should find message with dinner time content", 
                   result.contains("It is dinner time !"));
    }

    @Test
    public void testSearchByRecipient() {
        System.out.println("Testing Search by Recipient");
        
        MessageSystem.populateTestData();
        // Since searchMessagesByRecipient is private, we'll test the functionality indirectly
        // Or you can make that method public for testing
        
        // For now, let's test that we can call populateTestData without errors
        assertTrue("Test data should be populated", true);
    }

    @Test
    public void testDeleteByHash() {
        System.out.println("Testing Delete by Hash");
        
        MessageSystem.populateTestData();
        // Since deleteMessageByHash is private, we'll test indirectly
        // Or you can make it public for testing
        
        // Test that getSentMessagesArray works after populate
        String[] messages = MessageSystem.getSentMessagesArray();
        assertNotNull("Messages array should not be null", messages);
        assertTrue("Should have some messages", messages.length > 0);
    }

    @Test
    public void testFullReport() {
        System.out.println("Testing Full Report");
        
        MessageSystem.populateTestData();
        // Since displayFullReport is private and shows GUI, we'll test indirectly
        // Or you can extract the report generation logic into a public method
        
        // Test that basic functionality works
        String longest = MessageSystem.getLongestMessage();
        String[] messages = MessageSystem.getSentMessagesArray();
        
        assertNotNull("Longest message should work", longest);
        assertNotNull("Messages array should work", messages);
    }
}
