package chatapppoe;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestRunner {
    @Test
    public void testSomething() {
  
        System.out.println("=== QUICKCHAT COMPREHENSIVE TEST SUITE ===");
        System.out.println("Testing Parts 1, 2, and 3\n");
        
        // Test Part 1 - Registration & Validation
        System.out.println("--- PART 1: Registration & Validation ---");
        testPart1();
        
        // Test Part 2 - Messaging System
        System.out.println("\n--- PART 2: Messaging System ---");
        testPart2();
        
        // Test Part 3 - Data Management & Arrays
        System.out.println("\n--- PART 3: Data Management & Arrays ---");
        testPart3();
        
        System.out.println("\n=== ALL TESTS COMPLETED ===");
    }
    
    private static void testPart1() {
        int passed = 0;
        int total = 0;
        
        // Test username validation
        total++;
        if (ChatApp.checkUsername("user_name")) {
            System.out.println("✓ Valid username - PASSED");
            passed++;
        } else {
            System.out.println("✗ Valid username - FAILED");
        }
        
        total++;
        if (!ChatApp.checkUsername("user")) {
            System.out.println("✓ Invalid username (short) - PASSED");
            passed++;
        } else {
            System.out.println("✗ Invalid username (short) - FAILED");
        }
        
        total++;
        if (!ChatApp.checkUsername("username")) {
            System.out.println("✓ Invalid username (no underscore) - PASSED");
            passed++;
        } else {
            System.out.println("✗ Invalid username (no underscore) - FAILED");
        }
        
        // Test password validation
        total++;
        if (ChatApp.checkPasswordComplexity("Password1!")) {
            System.out.println("✓ Valid password - PASSED");
            passed++;
        } else {
            System.out.println("✗ Valid password - FAILED");
        }
        
        total++;
        if (!ChatApp.checkPasswordComplexity("pass")) {
            System.out.println("✓ Invalid password (short) - PASSED");
            passed++;
        } else {
            System.out.println("✗ Invalid password (short) - FAILED");
        }
        
        // Test phone validation
        total++;
        if (ChatApp.checkPhoneNumber("+27123456789")) {
            System.out.println("✓ Valid phone number - PASSED");
            passed++;
        } else {
            System.out.println("✗ Valid phone number - FAILED");
        }
        
        total++;
        if (!ChatApp.checkPhoneNumber("0123456789")) {
            System.out.println("✓ Invalid phone number - PASSED");
            passed++;
        } else {
            System.out.println("✗ Invalid phone number - FAILED");
        }
        
        System.out.println("Part 1 Results: " + passed + "/" + total + " tests passed");
    }
    
    private static void testPart2() {
        int passed = 0;
        int total = 0;
        
        // Test message length
        total++;
        if ("Message ready to send.".equals(MessageSystem.testMessageLength("Hello World"))) {
            System.out.println("✓ Message length validation (short) - PASSED");
            passed++;
        } else {
            System.out.println("✗ Message length validation (short) - FAILED");
        }
        
        total++;
        String longResult = MessageSystem.testMessageLength("A".repeat(255));
        if (longResult.contains("Message exceeds 250 characters by 5")) {
            System.out.println("✓ Message length validation (long) - PASSED");
            passed++;
        } else {
            System.out.println("✗ Message length validation (long) - FAILED");
        }
        
        // Test recipient validation
        total++;
        if ("Cell phone number successfully captured.".equals(MessageSystem.testRecipientNumber("+27718693002"))) {
            System.out.println("✓ Recipient validation (valid) - PASSED");
            passed++;
        } else {
            System.out.println("✗ Recipient validation (valid) - FAILED");
        }
        
        total++;
        String recipientResult = MessageSystem.testRecipientNumber("08575975889");
        if (recipientResult.contains("Cell phone number is incorrectly formatted")) {
            System.out.println("✓ Recipient validation (invalid) - PASSED");
            passed++;
        } else {
            System.out.println("✗ Recipient validation (invalid) - FAILED");
        }
        
        // Test message hash
        total++;
        String hash = MessageSystem.testMessageHash("1234567890", 1, "Hi Mike, can you join us for dinner tonight.");
        if ("12:1:HITONIGHT.".equals(hash)) {
            System.out.println("✓ Message hash generation - PASSED");
            passed++;
        } else {
            System.out.println("✗ Message hash generation - FAILED: " + hash);
        }
        
        // Test message actions
        total++;
        if ("Message successfully sent.".equals(MessageSystem.testMessageSent(1)) &&
            "Press 0 to delete message.".equals(MessageSystem.testMessageSent(2)) &&
            "Message successfully stored.".equals(MessageSystem.testMessageSent(3))) {
            System.out.println("✓ Message actions - PASSED");
            passed++;
        } else {
            System.out.println("✗ Message actions - FAILED");
        }
        
        System.out.println("Part 2 Results: " + passed + "/" + total + " tests passed");
    }
    
    private static void testPart3() {
        int passed = 0;
        int total = 0;
        
        // Initialize test data first
        MessageSystem.populateTestData();
        
        // Test array population
        total++;
        String[] sentArray = MessageSystem.getSentMessagesArray();
        if (sentArray != null && sentArray.length > 0) {
            System.out.println("✓ Sent messages array populated - PASSED");
            passed++;
        } else {
            System.out.println("✗ Sent messages array populated - FAILED");
        }
        
        // Test longest message
        total++;
        String longest = MessageSystem.getLongestMessage();
        if (longest != null && !longest.isEmpty()) {
            System.out.println("✓ Longest message retrieval - PASSED");
            passed++;
        } else {
            System.out.println("✗ Longest message retrieval - FAILED");
        }
        
        // Test message search by ID
        total++;
        String searchResult = MessageSystem.searchMessageById("0838884567");
        if (searchResult != null && searchResult.contains("0838884567")) {
            System.out.println("✓ Message search by ID - PASSED");
            passed++;
        } else {
            System.out.println("✗ Message search by ID - FAILED");
        }
        
        // Test data contains expected messages
        total++;
        boolean hasCakeMessage = false;
        boolean hasDinnerMessage = false;
        String[] messages = MessageSystem.getSentMessagesArray();
        
        if (messages != null) {
            for (String msg : messages) {
                if (msg != null) {
                    if (msg.contains("Did you get the cake?")) hasCakeMessage = true;
                    if (msg.contains("It is dinner time !")) hasDinnerMessage = true;
                }
            }
        }
        
        if (hasCakeMessage && hasDinnerMessage) {
            System.out.println("✓ Test data contains expected messages - PASSED");
            passed++;
        } else {
            System.out.println("✗ Test data contains expected messages - FAILED");
        }
        
        System.out.println("Part 3 Results: " + passed + "/" + total + " tests passed");
    }
}