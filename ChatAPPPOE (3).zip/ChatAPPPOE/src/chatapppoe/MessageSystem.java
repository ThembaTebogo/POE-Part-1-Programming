package chatapppoe;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.HeadlessException;
import javax.swing.*;
import java.util.*;
import java.util.regex.Pattern;
import java.io.*;
import java.nio.file.*;
/*import java.awt.*;*/ // ADD THIS IMPORT FOR DIMENSION

public class MessageSystem {
    private static final List<Message> sentMessages = new ArrayList<>();
    private static final List<Message> storedMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;
    private static int messageCounter = 1;
    
    // Arrays for Part 3 requirements
    private static String[] sentMessagesArray;
    private static String[] disregardedMessagesArray;
    private static String[] storedMessagesArray;
    private static String[] messageHashArray;
    private static String[] messageIdArray;
    
    // JSON file for stored messages
    private static final String STORED_MESSAGES_FILE = "stored_messages.json";

    public static void startMessageSystem(User loggedInUser) {
        if (loggedInUser == null) {
            JOptionPane.showMessageDialog(null, "Please login first!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Welcome message
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat, " + loggedInUser.getUsername() + "!");

        // Load stored messages from JSON
        loadStoredMessages();
        
        // Populate arrays with test data
        populateTestData();

        // Get number of messages
        String numMessagesStr = JOptionPane.showInputDialog("How many messages do you wish to send?");
        if (numMessagesStr == null) return;

        try {
            int numMessages = Integer.parseInt(numMessagesStr);
            runMessageMenu(loggedInUser, numMessages);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void runMessageMenu(User user, int maxMessages) {
        while (true) {
            String[] options = {"Send Messages", "Show recently sent messages", "Data Management", "Quit"};
            int choice = JOptionPane.showOptionDialog(null,
                    "Choose an option:",
                    "QuickChat Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]);

            switch (choice) {
                case 0 -> // Send Messages
                    sendMessages(user, maxMessages);
                case 1 -> // Show recent messages
                    showRecentMessages();
                case 2 -> // Data Management (Part 3 features)
                    showDataManagementMenu();
                case 3, JOptionPane.CLOSED_OPTION -> // Quit
                {
                    JOptionPane.showMessageDialog(null,
                            "Total messages sent: " + totalMessagesSent + "\nGoodbye!");
                    return;
                }
            }
            // Quit
                    }
    }

    // === PART 3: DATA MANAGEMENT MENU ===
    private static void showDataManagementMenu() {
        while (true) {
            String[] options = {
                "Display Sender/Recipient of Sent Messages",
                "Display Longest Sent Message", 
                "Search Message by ID",
                "Search Messages by Recipient",
                "Delete Message by Hash",
                "Display Full Report",
                "Back to Main Menu"
            };
            
            int choice = JOptionPane.showOptionDialog(null,
                    "Data Management - Choose an option:",
                    "Data Management",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]);

            switch (choice) {
                case 0 -> displaySenderRecipient();
                case 1 -> displayLongestMessage();
                case 2 -> searchMessageById();
                case 3 -> searchMessagesByRecipient();
                case 4 -> deleteMessageByHash();
                case 5 -> displayFullReport();
                case 6, JOptionPane.CLOSED_OPTION -> {
                    return;
                }
            }
        }
    }

    // === PART 3 FEATURE METHODS ===

    // a. Display sender and recipient of all sent messages
    private static void displaySenderRecipient() {
        if (sentMessagesArray == null || sentMessagesArray.length == 0) {
            JOptionPane.showMessageDialog(null, "No sent messages found.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("=== SENDER AND RECIPIENT OF SENT MESSAGES ===\n\n");
        
        for (int i = 0; i < sentMessagesArray.length; i++) {
            if (sentMessagesArray[i] != null && !sentMessagesArray[i].isEmpty()) {
                sb.append("Message ").append(i + 1).append(": ").append(sentMessagesArray[i]).append("\n");
            }
        }
        
        displayInScrollPane(sb.toString(), "Sender and Recipient Info");
    }

    // b. Display the longest sent message
    private static void displayLongestMessage() {
        if (sentMessagesArray == null || sentMessagesArray.length == 0) {
            JOptionPane.showMessageDialog(null, "No sent messages found.");
            return;
        }

        String longestMessage = "";
        for (String message : sentMessagesArray) {
            if (message != null && message.length() > longestMessage.length()) {
                longestMessage = message;
            }
        }

        JOptionPane.showMessageDialog(null, 
            "Longest Sent Message:\n\n" + longestMessage + 
            "\n\nLength: " + longestMessage.length() + " characters",
            "Longest Message", JOptionPane.INFORMATION_MESSAGE);
    }

    // c. Search for a message ID and display recipient and message
    private static void searchMessageById() {
        String searchId = JOptionPane.showInputDialog("Enter Message ID to search:");
        if (searchId == null || searchId.trim().isEmpty()) return;

        boolean found = false;
        StringBuilder sb = new StringBuilder();
        sb.append("=== SEARCH RESULTS FOR MESSAGE ID: ").append(searchId).append(" ===\n\n");

        for (int i = 0; i < messageIdArray.length; i++) {
            if (searchId.equals(messageIdArray[i]) && sentMessagesArray[i] != null) {
                sb.append("Message ID: ").append(messageIdArray[i]).append("\n");
                sb.append("Message: ").append(sentMessagesArray[i]).append("\n");
                sb.append("Message Hash: ").append(messageHashArray[i]).append("\n");
                found = true;
                break;
            }
        }

        if (!found) {
            sb.append("No message found with ID: ").append(searchId);
        }

        JOptionPane.showMessageDialog(null, sb.toString(), "Message Search", JOptionPane.INFORMATION_MESSAGE);
    }

    // d. Search for all messages sent to a particular recipient
    private static void searchMessagesByRecipient() {
        String recipient = JOptionPane.showInputDialog("Enter recipient phone number to search:");
        if (recipient == null || recipient.trim().isEmpty()) return;

        StringBuilder sb = new StringBuilder();
        sb.append("=== MESSAGES FOR RECIPIENT: ").append(recipient).append(" ===\n\n");
        boolean found = false;

        // Search in sent messages
        for (int i = 0; i < sentMessagesArray.length; i++) {
            if (sentMessagesArray[i] != null && sentMessagesArray[i].contains(recipient)) {
                sb.append("SENT - Message: ").append(sentMessagesArray[i]).append("\n");
                sb.append("Hash: ").append(messageHashArray[i]).append("\n\n");
                found = true;
            }
        }

        // Search in stored messages
        for (String storedMessagesArray1 : storedMessagesArray) {
            if (storedMessagesArray1 != null && storedMessagesArray1.contains(recipient)) {
                sb.append("STORED - Message: ").append(storedMessagesArray1).append("\n\n");
                found = true;
            }
        }

        if (!found) {
            sb.append("No messages found for recipient: ").append(recipient);
        }

        displayInScrollPane(sb.toString(), "Messages by Recipient");
    }

    // e. Delete a message using the message hash
    private static void deleteMessageByHash() {
        String hashToDelete = JOptionPane.showInputDialog("Enter Message Hash to delete:");
        if (hashToDelete == null || hashToDelete.trim().isEmpty()) return;

        boolean deleted = false;
        
        // Search and delete from sent messages
        for (int i = 0; i < messageHashArray.length; i++) {
            if (hashToDelete.equals(messageHashArray[i])) {
                sentMessagesArray[i] = null;
                messageHashArray[i] = null;
                messageIdArray[i] = null;
                deleted = true;
                break;
            }
        }

        if (deleted) {
            JOptionPane.showMessageDialog(null, "Message with hash '" + hashToDelete + "' has been deleted.");
            // Update arrays to remove nulls
            updateArraysAfterDeletion();
        } else {
            JOptionPane.showMessageDialog(null, "No message found with hash: " + hashToDelete);
        }
    }

    // f. Display a report of all sent messages
    private static void displayFullReport() {
        if (sentMessagesArray == null || sentMessagesArray.length == 0) {
            JOptionPane.showMessageDialog(null, "No sent messages to display.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("=== FULL MESSAGE REPORT ===\n\n");
        
        for (int i = 0; i < sentMessagesArray.length; i++) {
            if (sentMessagesArray[i] != null) {
                sb.append("Message ").append(i + 1).append(":\n");
                sb.append("  Message Hash: ").append(messageHashArray[i]).append("\n");
                sb.append("  Recipient: ").append(extractRecipient(sentMessagesArray[i])).append("\n");
                sb.append("  Message: ").append(extractMessageText(sentMessagesArray[i])).append("\n");
                sb.append("  Message ID: ").append(messageIdArray[i]).append("\n");
                sb.append("  -------------------------\n");
            }
        }

        displayInScrollPane(sb.toString(), "Full Message Report");
    }

   
    public static void populateTestData() {
    // Initialize arrays with size 10
    sentMessagesArray = new String[10];
    disregardedMessagesArray = new String[10];
    storedMessagesArray = new String[10];
    messageHashArray = new String[10];
    messageIdArray = new String[10];

    // Test Data Message 1: Sent
    sentMessagesArray[0] = "Sender: System, Recipient: +27834557896, Message: Did you get the cake?";
    messageHashArray[0] = "12:1:DIDCAKE?";
    messageIdArray[0] = "1234567890";

    // Test Data Message 2: Stored
    storedMessagesArray[0] = "Sender: System, Recipient: +27838884567, Message: Where are you? You are late! I have asked you to be on time.";
    messageHashArray[1] = "12:2:WHERETIME.";

    // Test Data Message 3: Disregarded
    disregardedMessagesArray[0] = "Sender: System, Recipient: +27834484567, Message: Yohoooo, I am at your gate.";
    messageHashArray[2] = "12:3:YOHOOGATE.";

    // Test Data Message 4: Sent
    sentMessagesArray[1] = "Sender: System, Recipient: 0838884567, Message: It is dinner time !";
    messageHashArray[3] = "12:4:IT!";
    messageIdArray[1] = "0838884567";

    // Test Data Message 5: Stored
    storedMessagesArray[1] = "Sender: System, Recipient: +27838884567, Message: Ok, I am leaving without you.";
    messageHashArray[4] = "12:5:OKYOU.";
}
   

    private static void loadStoredMessages() {
        try {
            File file = new File(STORED_MESSAGES_FILE);
            if (file.exists()) {
                String content = new String(Files.readAllBytes(file.toPath()));
                // Simple JSON parsing - in real app, use GSON or Jackson
                if (content.contains("storedMessages")) {
                    JOptionPane.showMessageDialog(null, "Stored messages loaded from file.");
                }
            }
        } catch (HeadlessException | IOException e) {
            // File doesn't exist or error reading - that's OK
        }
    }

    private static void saveStoredMessages() {
        try {
            // Simple JSON representation
            String json = "{\"storedMessages\": " + storedMessages.toString() + "}";
            Files.write(Paths.get(STORED_MESSAGES_FILE), json.getBytes());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving stored messages: " + e.getMessage());
        }
    }

    private static void updateArraysAfterDeletion() {
        // Remove null values from arrays
        List<String> tempSent = new ArrayList<>();
        List<String> tempHash = new ArrayList<>();
        List<String> tempId = new ArrayList<>();

        for (int i = 0; i < sentMessagesArray.length; i++) {
            if (sentMessagesArray[i] != null) {
                tempSent.add(sentMessagesArray[i]);
                tempHash.add(messageHashArray[i]);
                tempId.add(messageIdArray[i]);
            }
        }

        sentMessagesArray = tempSent.toArray(String[]::new);
        messageHashArray = tempHash.toArray(String[]::new);
        messageIdArray = tempId.toArray(String[]::new);
    }

    private static String extractRecipient(String messageData) {
        if (messageData == null) return "";
        String[] parts = messageData.split(", ");
        for (String part : parts) {
            if (part.startsWith("Recipient: ")) {
                return part.substring(11);
            }
        }
        return "";
    }

    private static String extractMessageText(String messageData) {
        if (messageData == null) return "";
        String[] parts = messageData.split(", ");
        for (String part : parts) {
            if (part.startsWith("Message: ")) {
                return part.substring(9);
            }
        }
        return "";
    }

    private static void displayInScrollPane(String text, String title) {
        JTextArea textArea = new JTextArea(text, 20, 50);
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(600, 400)); // FIXED: Dimension now imported
        
        JOptionPane.showMessageDialog(null, scrollPane, title, JOptionPane.INFORMATION_MESSAGE);
    }

    // === REST OF YOUR EXISTING METHODS ===
    
    private static void sendMessages(User user, int maxMessages) {
        for (int i = 0; i < maxMessages; i++) {
            Message message = createMessage(user);
            if (message != null) {
                handleMessageAction(message);
            } else {
                break;
            }
        }
        
        JOptionPane.showMessageDialog(null, 
            "All messages processed!\nTotal sent: " + totalMessagesSent);
    }

    private static Message createMessage() {
        String recipient = JOptionPane.showInputDialog("Enter recipient phone number (+27 format):");
        if (recipient == null) return null;

        if (!checkRecipientCell(recipient)) {
            JOptionPane.showMessageDialog(null, 
                "Cell phone number is incorrectly formatted.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        String messageText = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
        if (messageText == null) return null;

        if (!checkMessageLength(messageText)) {
            JOptionPane.showMessageDialog(null, 
                "Message exceeds 250 characters by " + (messageText.length() - 250), "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        String messageId = generateMessageId();
        String messageHash = createMessageHash(messageId, messageCounter, messageText);
        
        return new Message(messageId, messageCounter, recipient, messageText, messageHash);
    }

    private static void handleMessageAction(Message message) {
        String[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        int action = JOptionPane.showOptionDialog(null,
                "Message ready:\n" + message.getPreview(),
                "Message Action",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        switch (action) {
            case 0 -> // Send
                sendMessage(message);
            case 1 -> // Disregard
                JOptionPane.showMessageDialog(null, "Press 0 to delete message.");
            case 2 -> {
                // Store
                storeMessage(message);
                JOptionPane.showMessageDialog(null, "Message successfully stored.");
            }
        }
    }

    private static void sendMessage(Message message) {
        sentMessages.add(message);
        totalMessagesSent++;
        messageCounter++;
        
        JOptionPane.showMessageDialog(null, 
            """
            Message sent successfully!
            MessageID: """ + message.getMessageId() + "\n" +
            "Message Hash: " + message.getMessageHash() + "\n" +
            "Recipient: " + message.getRecipient() + "\n" +
            "Message: " + message.getMessageText());
    }

    private static Message createMessage(User user) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // === MESSAGE CLASS ===
    public static class Message {
        private final String messageId;
        private final int messageNumber;
        private final String recipient;
        private final String messageText;
        private final String messageHash;

        public Message(String messageId, int messageNumber, String recipient, String messageText, String messageHash) {
            this.messageId = messageId;
            this.messageNumber = messageNumber;
            this.recipient = recipient;
            this.messageText = messageText;
            this.messageHash = messageHash;
        }

        public String getMessageId() { return messageId; }
        public int getMessageNumber() { return messageNumber; }
        public String getRecipient() { return recipient; }
        public String getMessageText() { return messageText; }
        public String getMessageHash() { return messageHash; }

        public String getPreview() {
            return "To: " + recipient + "\nMessage: " + 
                   (messageText.length() > 50 ? messageText.substring(0, 50) + "..." : messageText);
        }
    }

    // === VALIDATION METHODS ===
    public static boolean checkMessageLength(String message) {
        return message != null && message.length() <= 250;
    }

    public static boolean checkRecipientCell(String recipient) {
        if (recipient == null) return false;
        Pattern phonePattern = Pattern.compile("^\\+27\\d{8,9}$");
        return phonePattern.matcher(recipient).matches();
    }

    public static String generateMessageId() {
        Random rand = new Random();
        long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }

    public static String createMessageHash(String messageId, int messageNumber, String messageText) {
        if (messageText == null || messageText.trim().isEmpty()) {
            String firstTwoId = messageId.length() >= 2 ? messageId.substring(0, 2) : messageId;
            return (firstTwoId + ":" + messageNumber + ":").toUpperCase();
        }
        
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        
        String firstTwoId = messageId.length() >= 2 ? messageId.substring(0, 2) : messageId;
        
        return (firstTwoId + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    public static void storeMessage(Message message) {
        storedMessages.add(message);
        saveStoredMessages();
    }

    private static void showRecentMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("=== RECENTLY SENT MESSAGES ===\n");
        
        for (Message msg : sentMessages) {
            sb.append("To: ").append(msg.getRecipient()).append("\n");
            sb.append("Message: ").append(msg.getMessageText()).append("\n");
            sb.append("Hash: ").append(msg.getMessageHash()).append("\n");
            sb.append("------------------------\n");
        }
        
        JOptionPane.showMessageDialog(null, sb.toString(), "Recent Messages", JOptionPane.INFORMATION_MESSAGE);
    }

    // === TEST METHODS FOR JUNIT ===
    public static String testMessageLength(String message) {
        if (checkMessageLength(message)) {
            return "Message ready to send.";
        } else {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
    }

    public static String testRecipientNumber(String recipient) {
        if (checkRecipientCell(recipient)) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }
    
    public static String testSearchByRecipient(String recipient) {
    StringBuilder sb = new StringBuilder();
    boolean found = false;

        // Search in sent messages
        for (String sentMessagesArray1 : sentMessagesArray) {
            if (sentMessagesArray1 != null && sentMessagesArray1.contains(recipient)) {
                sb.append("SENT - ").append(sentMessagesArray1).append("\n");
                found = true;
            }
        }

    if (!found) {
        sb.append("No messages found for recipient: ").append(recipient);
    }
    return sb.toString();
}

public static boolean testDeleteByHash(String hash) {
    boolean deleted = false;
    
    for (int i = 0; i < messageHashArray.length; i++) {
        if (hash.equals(messageHashArray[i])) {
            sentMessagesArray[i] = null;
            messageHashArray[i] = null;
            messageIdArray[i] = null;
            deleted = true;
            break;
        }
    }

    if (deleted) {
        updateArraysAfterDeletion();
    }
    return deleted;
}

public static String testGenerateFullReport() {
    if (sentMessagesArray == null || sentMessagesArray.length == 0) {
        return "No sent messages to display.";
    }

    StringBuilder sb = new StringBuilder();
    sb.append("=== FULL MESSAGE REPORT ===\n\n");
    
    for (int i = 0; i < sentMessagesArray.length; i++) {
        if (sentMessagesArray[i] != null) {
            sb.append("Message ").append(i + 1).append(":\n");
            sb.append("  Message: ").append(sentMessagesArray[i]).append("\n");
            sb.append("  Hash: ").append(messageHashArray[i]).append("\n");
            sb.append("  ID: ").append(messageIdArray[i]).append("\n");
            sb.append("  -------------------------\n");
        }
    }
    return sb.toString();
}
    
    public static String testMessageHash(String messageId, int messageNumber, String messageText) {
        return createMessageHash(messageId, messageNumber, messageText);
    }

    public static String testMessageSent(int action) {
        return switch (action) {
            case 1 -> "Message successfully sent.";
            case 2 -> "Press 0 to delete message.";
            case 3 -> "Message successfully stored.";
            default -> "Invalid action.";
        };
    }

    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    // === PART 3 TEST METHODS ===
    public static String[] getSentMessagesArray() {
        return sentMessagesArray;
    }

    public static String getLongestMessage() {
        if (sentMessagesArray == null) return "";
        String longest = "";
        for (String msg : sentMessagesArray) {
            if (msg != null && msg.length() > longest.length()) {
                longest = msg;
            }
        }
        return longest;
    }

    public static String searchMessageById(String messageId) {
        for (int i = 0; i < messageIdArray.length; i++) {
            if (messageId.equals(messageIdArray[i]) && sentMessagesArray[i] != null) {
                return sentMessagesArray[i];
            }
        }
        return "";
    }
}