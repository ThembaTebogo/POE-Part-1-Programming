/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapppoe;

import javax.swing.*;
import java.util.*;
import java.util.regex.Pattern;

public class MessageSystem {
    private static final List<Message> sentMessages = new ArrayList<>();
    private static final List<Message> storedMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;
    private static int messageCounter = 1;

    public static void startMessageSystem(User loggedInUser) {
        if (loggedInUser == null) {
            JOptionPane.showMessageDialog(null, "Please login first!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Welcome message
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat, " + loggedInUser.getUsername() + "!");

        // Get number of messages
        String numMessagesStr = JOptionPane.showInputDialog("How many messages do you wish to send?");
        if (numMessagesStr == null) return;

        try {
            int numMessages = Integer.parseInt(numMessagesStr);
            runMessageMenu(loggedInUser, numMessages);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void runMessageMenu(User user, int maxMessages) {
        while (true) {
            String[] options = {"Send Messages", "Show recently sent messages", "Quit"};
            int choice = JOptionPane.showOptionDialog(null,
                    "Choose an option:",
                    "QuickChat Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]);

            switch (choice) {
                case 0: // Send Messages
                    sendMessages(user, maxMessages);
                    break;
                case 1: // Show recent messages
                    JOptionPane.showMessageDialog(null, "Coming Soon.");
                    break;
                case 2: // Quit
                case JOptionPane.CLOSED_OPTION:
                    JOptionPane.showMessageDialog(null, 
                        "Total messages sent: " + totalMessagesSent + "\nGoodbye!");
                    return;
            }
        }
    }

    private static void sendMessages(User user, int maxMessages) {
        for (int i = 0; i < maxMessages; i++) {
            Message message = createMessage(user);
            if (message != null) {
                handleMessageAction(message);
            } else {
                break; // User cancelled message creation
            }
        }
        
        JOptionPane.showMessageDialog(null, 
            "All messages processed!\nTotal sent: " + totalMessagesSent + 
            "\nStored: " + storedMessages.size());
    }

    private static Message createMessage(User user) {
        // Recipient input
        String recipient = JOptionPane.showInputDialog("Enter recipient phone number (+27 format):");
        if (recipient == null) return null;

        if (!checkRecipientCell(recipient)) {
            JOptionPane.showMessageDialog(null, 
                "Cell phone number is incorrectly formatted or does not contain an international code.", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        // Message input
        String messageText = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
        if (messageText == null) return null;

        if (!checkMessageLength(messageText)) {
            JOptionPane.showMessageDialog(null, 
                "Message exceeds 250 characters by " + (messageText.length() - 250) + 
                ", please reduce size.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        // Create message object
        String messageId = generateMessageId();
        String messageHash = createMessageHash(messageId, messageCounter, messageText);
        
        return new Message(messageId, messageCounter, recipient, messageText, messageHash);
    }

    private static void handleMessageAction(Message message) {
        String[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        int action = JOptionPane.showOptionDialog(null,
                "Message ready:\n" + message.getPreview(),
                "Message Action",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        switch (action) {
            case 0 -> // Send
                sendMessage(message);
            case 1 -> // Disregard
                JOptionPane.showMessageDialog(null, "Press 0 to delete message.");
            case 2 -> {
                // Store
                storeMessage(message);
                JOptionPane.showMessageDialog(null, "Message successfully stored.");
            }
        }
    }

    private static void sendMessage(Message message) {
        sentMessages.add(message);
        totalMessagesSent++;
        messageCounter++;
        
        // Display message details
        JOptionPane.showMessageDialog(null, 
            """
            Message sent successfully!
            MessageID: """ + message.getMessageId() + "\n" +
            "Message Hash: " + message.getMessageHash() + "\n" +
            "Recipient: " + message.getRecipient() + "\n" +
            "Message: " + message.getMessageText() + "\n\n" +
            "Message ready to send.");
    }

    // === MESSAGE CLASS ===
    public static class Message {
        private final String messageId;
        private final int messageNumber;
        private final String recipient;
        private final String messageText;
        private final String messageHash;

        public Message(String messageId, int messageNumber, String recipient, String messageText, String messageHash) {
            this.messageId = messageId;
            this.messageNumber = messageNumber;
            this.recipient = recipient;
            this.messageText = messageText;
            this.messageHash = messageHash;
        }

        public String getMessageId() { return messageId; }
        public int getMessageNumber() { return messageNumber; }
        public String getRecipient() { return recipient; }
        public String getMessageText() { return messageText; }
        public String getMessageHash() { return messageHash; }

        public String getPreview() {
            return "To: " + recipient + "\nMessage: " + 
                   (messageText.length() > 50 ? messageText.substring(0, 50) + "..." : messageText);
        }
    }

    // === VALIDATION METHODS ===
    public static boolean checkMessageLength(String message) {
        return message != null && message.length() <= 250;
    }

    public static boolean checkRecipientCell(String recipient) {
        if (recipient == null) return false;
        Pattern phonePattern = Pattern.compile("^\\+27\\d{8,9}$");
        return phonePattern.matcher(recipient).matches();
    }

    public static String generateMessageId() {
        Random rand = new Random();
        long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }

    public static String createMessageHash(String messageId, int messageNumber, String messageText) {
        if (messageText == null || messageText.trim().isEmpty()) {
            String firstTwoId = messageId.length() >= 2 ? messageId.substring(0, 2) : messageId;
            return (firstTwoId + ":" + messageNumber + ":").toUpperCase();
        }
        
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        
        String firstTwoId = messageId.length() >= 2 ? messageId.substring(0, 2) : messageId;
        
        return (firstTwoId + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    public static void storeMessage(Message message) {
        storedMessages.add(message);
    }

    // === TEST METHODS FOR JUNIT ===
    public static String testMessageLength(String message) {
        if (checkMessageLength(message)) {
            return "Message ready to send.";
        } else {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
    }

    public static String testRecipientNumber(String recipient) {
        if (checkRecipientCell(recipient)) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    public static String testMessageHash(String messageId, int messageNumber, String messageText) {
        return createMessageHash(messageId, messageNumber, messageText);
    }

    public static String testMessageSent(int action) {
        return switch (action) {
            case 1 -> "Message successfully sent.";
            case 2 -> "Press 0 to delete message.";
            case 3 -> "Message successfully stored.";
            default -> "Invalid action.";
        };
    }

    public static int returnTotalMessages() {
        return totalMessagesSent;
    }
}