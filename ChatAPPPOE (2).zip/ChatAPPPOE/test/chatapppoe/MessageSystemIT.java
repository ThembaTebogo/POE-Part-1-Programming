/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package chatapppoe;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Themb
 */
public class MessageSystemIT {
    
    public MessageSystemIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of testMessageLength method, of class MessageSystem.
     */
    @Test
    public void testTestMessageLength() {
        System.out.println("testMessageLength");
        
        // Test short message (should pass)
        String shortMessage = "Hello World";
        String expResult = "Message ready to send.";
        String result = MessageSystem.testMessageLength(shortMessage);
        assertEquals(expResult, result);
        
        // Test long message (should fail)
        String longMessage = "A".repeat(255);
        String longResult = MessageSystem.testMessageLength(longMessage);
        assertTrue(longResult.contains("Message exceeds 250 characters by 5"));
    }

    /**
     * Test of testRecipientNumber method, of class MessageSystem.
     */
    @Test
    public void testTestRecipientNumber() {
        System.out.println("testRecipientNumber");
        
        // Test valid number
        String validNumber = "+27718693002";
        String expResult = "Cell phone number successfully captured.";
        String result = MessageSystem.testRecipientNumber(validNumber);
        assertEquals(expResult, result);
        
        // Test invalid number
        String invalidNumber = "08575975889";
        String invalidResult = MessageSystem.testRecipientNumber(invalidNumber);
        assertTrue(invalidResult.contains("Cell phone number is incorrectly formatted"));
    }

    /**
     * Test of testMessageHash method, of class MessageSystem.
     */
    @Test
    public void testTestMessageHash() {
        System.out.println("testMessageHash");
        String messageId = "1234567890";
        int messageNumber = 1;
        String messageText = "Hi Mike, can you join us for dinner tonight.";
        String expResult = "12:1:HITONIGHT.";
        String result = MessageSystem.testMessageHash(messageId, messageNumber, messageText);
        assertEquals(expResult, result);
    }

    /**
     * Test of testMessageSent method, of class MessageSystem.
     */
    @Test
    public void testTestMessageSent() {
        System.out.println("testMessageSent");
        
        // Test action 1 - Send
        String expResult1 = "Message successfully sent.";
        String result1 = MessageSystem.testMessageSent(1);
        assertEquals(expResult1, result1);
        
        // Test action 2 - Disregard
        String expResult2 = "Press 0 to delete message.";
        String result2 = MessageSystem.testMessageSent(2);
        assertEquals(expResult2, result2);
        
        // Test action 3 - Store
        String expResult3 = "Message successfully stored.";
        String result3 = MessageSystem.testMessageSent(3);
        assertEquals(expResult3, result3);
        
        // Test invalid action
        String expResult4 = "Invalid action.";
        String result4 = MessageSystem.testMessageSent(0);
        assertEquals(expResult4, result4);
    }

    /**
     * Test of returnTotalMessages method, of class MessageSystem.
     */
    @Test
    public void testReturnTotalMessages() {
        System.out.println("returnTotalMessages");
        int result = MessageSystem.returnTotalMessages();
        // This should return the current count (could be 0 or more)
        assertTrue(result >= 0);
    }

    /**
     * Test of createMessageHash method, of class MessageSystem.
     */
    @Test
public void testCreateMessageHash() {
    System.out.println("createMessageHash");
    String messageId = "9876543210";
    int messageNumber = 2;
    String messageText = "Hello World Test";
    
    // According to the requirements: first word "Hello" + last word "Test" = "HELLOTEST"
    String expResult = "98:2:HELLOTEST";
    String result = MessageSystem.createMessageHash(messageId, messageNumber, messageText);
    assertEquals(expResult, result);
}

    /**
     * Test of checkRecipientCell method, of class MessageSystem.
     */
    @Test
    public void testCheckRecipientCell() {
        System.out.println("checkRecipientCell");
        
        // Test valid number
        String validRecipient = "+27123456789";
        boolean expResultValid = true;
        boolean resultValid = MessageSystem.checkRecipientCell(validRecipient);
        assertEquals(expResultValid, resultValid);
        
        // Test invalid number
        String invalidRecipient = "0123456789";
        boolean expResultInvalid = false;
        boolean resultInvalid = MessageSystem.checkRecipientCell(invalidRecipient);
        assertEquals(expResultInvalid, resultInvalid);
    }

    /**
     * Test of checkMessageLength method, of class MessageSystem.
     */
    @Test
    public void testCheckMessageLength() {
        System.out.println("checkMessageLength");
        
        // Test short message (should return true)
        String shortMessage = "Short message";
        boolean expResultShort = true;
        boolean resultShort = MessageSystem.checkMessageLength(shortMessage);
        assertEquals(expResultShort, resultShort);
        
        // Test long message (should return false)
        String longMessage = "A".repeat(300);
        boolean expResultLong = false;
        boolean resultLong = MessageSystem.checkMessageLength(longMessage);
        assertEquals(expResultLong, resultLong);
        
        // Test empty string (should return true)
        boolean expResultEmpty = true;
        boolean resultEmpty = MessageSystem.checkMessageLength("");
        assertEquals(expResultEmpty, resultEmpty);
        
        // Test null (should return false)
        boolean expResultNull = false;
        boolean resultNull = MessageSystem.checkMessageLength(null);
        assertEquals(expResultNull, resultNull);
    }
}
